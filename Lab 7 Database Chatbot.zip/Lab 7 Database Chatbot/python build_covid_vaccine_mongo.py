# -*- coding: utf-8 -*-
"""
Created on Sat May  3 15:29:21 2025

@author: vaidy
"""

from pymongo import MongoClient

# Connect to MongoDB databse application
client = MongoClient("mongodb://localhost:27017/") #Local host link
db = client["EE104LabSeven"]  # Database name
collection = db["Covid Vaccine Database"]  # Collection name

#This block of code allows us to enter the databe information 
records = [
    {
        "Person Number:": 1,
        "First Name":"Divyang",
        "Middle Name": "middle",
        "Last Name": "Vaidya",
        "Date of Birth": "May 13, 1999",
        "Phone Number": 6692854354,
        "Email": "vaidya.dave@yahoo.com",
        "City": "San Jose",
        "Date of 1st Covid Shot": "May 13, 2021",
        "Date of 2nd Covid Shot": "May 15, 2022",
        "Vaccine Brand": "Pfizer",
    },
    {
        "Person Number:": 2,
        "First Name":"Steph",
        "Middle Name": "Stephen",
        "Last Name": "Curry",
        "Date of Birth": "March 14, 1988",
        "Phone Number": 6694567891,
        "Email": "stephcurry@gmail.com",
        "City": "San Francisco",
        "Date of 1st Covid Shot": "April 13, 2021",
        "Date of 2nd Covid Shot": "May 20, 2022",
        "Vaccine Brand": "Moderna",
    },
    {
        "Person Number": 3,
        "First Name": "JOhn",
        "Middle Name": "Hamilton",
        "Last Name": "Smith",
        "Date of Birth": "October 5, 1976",
        "Phone Number": 4103457654,
        "Email" : "johnHamilton@outlook.com",
        "City": "Kansas",
        "Date of 1st Covid Shot": "April 13, 2024",
        "Date of 2nd Covid Shot": "",
        "Vaccine Brand": "Moderna",
    },
    {
        "Person Number": 4,
        "First Name": "Peter",
        "Middle Name": "John",
        "Last Name": "Parker",
        "Date of Birth": "October 10, 1987",
        "Phone Number": 6691234567,
        "Email" : "peterparker@yahoo.com",
        "City": "New York",
        "Date of 1st Covid Shot": "April 18, 2022",
        "Date of 2nd Covid Shot": "June 13, 2022",
        "Vaccine Brand": "Pfizer"
    },
    {
        "Person Number": 5,
        "First Name": "Bruce",
        "Middle Name": "woodland",
        "Last Name": "Wayne",
        "Date of Birth": "September 5, 1976",
        "Phone Number": 6694672145,
        "Email" : "brucewayne@gmail.com",
        "City": "San Diego",
        "Date of 1st Covid Shot": "April 18, 2021",
        "Date of 2nd Covid Shot": "",
        "Vaccine Brand": "Moderna"
    },
    {
        "Person Number": 6,
        "First Name": "Tony",
        "Middle Name": "Iron",
        "Last Name": "Stark",
        "Date of Birth": "November 12, 1974", #Used Date of birth parameter
        "Phone Number": 4087654567,
        "Email" : "tonystark@yahoo.com",
        "City": "Chicago",
        "Date of 1st Covid Shot": "August 13, 2022",
        "Date of 2nd Covid Shot": "July 23, 2023",
        "Vaccine Brand": "Pfizer" #Used Vaccine brand parameter
    },
    {
        "Person Number": 7,
        "First Name": "Clark",
        "Middle Name": "Donald",
        "Last Name": "Kent",
        "Date of Birth": "January 23, 1983",
        "Phone Number": 4085646543,
        "Email" : "clarkkent@gmail.com",
        "City": "Palm Beach",
        "Date of 1st Covid Shot": "September 2, 2022",
        "Date of 2nd Covid Shot": "December 5, 2022",
        "Vaccine Brand": "Moderna"
    }
]

# Insert into MongoDB
collection.insert_many(records)

print(f"Inserted {len(records)} records into 'EE104.CovidVaccine'")
