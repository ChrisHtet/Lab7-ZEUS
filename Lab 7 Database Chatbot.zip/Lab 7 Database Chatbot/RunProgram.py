# -*- coding: utf-8 -*-
"""
Created on Sat May  3 15:45:56 2025

@author: vaidy
"""

from pymongo import MongoClient
from langchain_openai import ChatOpenAI
import os
from dotenv import load_dotenv

# Load API key from .env file in the current directory
from pathlib import Path
load_dotenv(dotenv_path=Path(__file__).resolve().parent / "env_example.env")  # Make sure your .env file is named exactly ".env"

# Step 1: Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["EE104LabSeven"]
collection = db["Covid Vaccine Database"]

# Step 2: Retrieve all documents as context
def get_covid_vaccine_data():
    records = list(collection.find({}, {"_id": 0}))
    return "\n".join([str(rec) for rec in records])

# Step 3: Define the chatbot logic
def ask_question(question):
    print("DEBUG: Loaded API key is", os.getenv("OPENAI_API_KEY"))
    context = get_covid_vaccine_data()
    prompt = f"""
You are an expert assistant who answers questions based on the following vaccine data from a MongoDB database:

{context}

Now answer this question: {question}
"""#This block of code allows us to declare the APIkey and use the GPT model
    llm = ChatOpenAI(
        model_name="gpt-3.5-turbo",
        temperature=0,
        openai_api_key=os.getenv("OPENAI_API_KEY")
    )
    return llm.invoke(prompt).content

# Step 4: Run the chatbot loop
def run_chatbot():
    print("Welcome to the COVID Vaccine Chatbot! (Type 'exit' to quit)")
    while True:
        user_input = input(">> ")
        if user_input.lower() == "exit":
            print("Goodbye!")
            break
        try:
            response = ask_question(user_input)
            print(response)
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    run_chatbot()
