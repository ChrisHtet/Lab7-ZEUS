from random import randint
import pgzrun
from pgzero.builtins import Actor, clock

WIDTH = 800
HEIGHT = 600
CENTER_X = WIDTH / 2
CENTER_Y = HEIGHT / 2

# Game variables
move_list = []
display_list = []
score_p1 = 0  # Player 1 score (arrow keys)
score_p2 = 0  # Player 2 score (WASD keys)
current_move = 0
count = 4
dance_length = 4
say_dance = False
show_countdown = True
moves_complete = False
game_over = False
current_player = 1  # 1 for Player 1, 2 for Player 2
player_turn_message = "Player 1's turn (Arrow keys)"

# Actors - Player 1 (left side)
dancer_p1 = Actor("dancer-start")
dancer_p1.pos = CENTER_X - 150, CENTER_Y - 40

up_p1 = Actor("up")
up_p1.pos = CENTER_X - 150, CENTER_Y + 110
right_p1 = Actor("right")
right_p1.pos = CENTER_X - 90, CENTER_Y + 170
down_p1 = Actor("down")
down_p1.pos = CENTER_X - 150, CENTER_Y + 230
left_p1 = Actor("left")
left_p1.pos = CENTER_X - 210, CENTER_Y + 170

# Actors - Player 2 (right side)
dancer_p2 = Actor("dancer-start")
dancer_p2.pos = CENTER_X + 150, CENTER_Y - 40

up_p2 = Actor("up")
up_p2.pos = CENTER_X + 150, CENTER_Y + 110
right_p2 = Actor("right")
right_p2.pos = CENTER_X + 210, CENTER_Y + 170
down_p2 = Actor("down")
down_p2.pos = CENTER_X + 150, CENTER_Y + 230
left_p2 = Actor("left")
left_p2.pos = CENTER_X + 90, CENTER_Y + 170


def draw():
    global game_over, score_p1, score_p2, say_dance
    global count, show_countdown, player_turn_message

    screen.clear()
    screen.blit("stage", (0, 0))

    # Draw both players
    dancer_p1.draw()
    up_p1.draw()
    right_p1.draw()
    down_p1.draw()
    left_p1.draw()

    dancer_p2.draw()
    up_p2.draw()
    right_p2.draw()
    down_p2.draw()
    left_p2.draw()

    # Display scores and turn information
    screen.draw.text(f"Player 1 (Arrows): {score_p1}", color="black", topleft=(10, 10))
    screen.draw.text(f"Player 2 (WASD): {score_p2}", color="black", topleft=(10, 40))
    screen.draw.text(player_turn_message, color="black", midtop=(CENTER_X, 70), fontsize=30)

    if not game_over:
        if say_dance:
            screen.draw.text("Dance!", color="black", topleft=(CENTER_X - 65, 150), fontsize=60)
        if show_countdown:
            screen.draw.text(str(count), color="black", topleft=(CENTER_X - 8, 150), fontsize=60)
    else:
        screen.draw.text("GAME OVER!", color="black", topleft=(CENTER_X - 130, 220), fontsize=60)


def reset_dancers():
    global game_over
    if not game_over:
        # Reset both dancers
        dancer_p1.image = "dancer-start"
        up_p1.image = "up"
        right_p1.image = "right"
        down_p1.image = "down"
        left_p1.image = "left"

        dancer_p2.image = "dancer-start"
        up_p2.image = "up"
        right_p2.image = "right"
        down_p2.image = "down"
        left_p2.image = "left"


def update_dancer(move):
    global game_over, current_player
    if not game_over:
        if current_player == 1:
            # Update player 1's dancer and buttons
            if move == 0:
                up_p1.image = "up-lit"
                dancer_p1.image = "dancer-up"
            elif move == 1:
                right_p1.image = "right-lit"
                dancer_p1.image = "dancer-right"
            elif move == 2:
                down_p1.image = "down-lit"
                dancer_p1.image = "dancer-down"
            else:
                left_p1.image = "left-lit"
                dancer_p1.image = "dancer-left"
        else:
            # Update player 2's dancer and buttons
            if move == 0:
                up_p2.image = "up-lit"
                dancer_p2.image = "dancer-up"
            elif move == 1:
                right_p2.image = "right-lit"
                dancer_p2.image = "dancer-right"
            elif move == 2:
                down_p2.image = "down-lit"
                dancer_p2.image = "dancer-down"
            else:
                left_p2.image = "left-lit"
                dancer_p2.image = "dancer-left"

        clock.schedule(reset_dancers, 0.5)


def display_moves():
    global move_list, display_list, dance_length
    global say_dance, show_countdown, current_move

    if display_list:
        this_move = display_list[0]
        display_list = display_list[1:]
        update_dancer(this_move)
        clock.schedule(display_moves, 1)
    else:
        say_dance = True
        show_countdown = False


def generate_moves():
    global move_list, dance_length, count
    global show_countdown, say_dance, current_player, player_turn_message

    count = 4
    move_list = []
    say_dance = False

    # Update player turn message
    if current_player == 1:
        player_turn_message = "Player 1's turn (Arrow keys)"
    else:
        player_turn_message = "Player 2's turn (WASD keys)"

    for move in range(0, dance_length):
        rand_move = randint(0, 3)
        move_list.append(rand_move)
        display_list.append(rand_move)

    show_countdown = True
    countdown()


def countdown():
    global count, game_over, show_countdown
    if count > 1:
        count = count - 1
        clock.schedule(countdown, 1)
    else:
        show_countdown = False
        display_moves()


def next_move():
    global dance_length, current_move, moves_complete
    if current_move < dance_length - 1:
        current_move = current_move + 1
    else:
        moves_complete = True


def on_key_up(key):
    global score_p1, score_p2, game_over, move_list, current_move
    global current_player, moves_complete, dance_length

    if not say_dance or game_over:
        return

    # Player 1 controls (arrow keys)
    if current_player == 1:
        if key == keys.UP:
            update_dancer(0)
            if move_list[current_move] == 0:
                score_p1 += 1
                next_move()
            else:
                game_over = True
        elif key == keys.RIGHT:
            update_dancer(1)
            if move_list[current_move] == 1:
                score_p1 += 1
                next_move()
            else:
                game_over = True
        elif key == keys.DOWN:
            update_dancer(2)
            if move_list[current_move] == 2:
                score_p1 += 1
                next_move()
            else:
                game_over = True
        elif key == keys.LEFT:
            update_dancer(3)
            if move_list[current_move] == 3:
                score_p1 += 1
                next_move()
            else:
                game_over = True

    # Player 2 controls (WASD keys)
    elif current_player == 2:
        if key == keys.W:
            update_dancer(0)
            if move_list[current_move] == 0:
                score_p2 += 1
                next_move()
            else:
                game_over = True
        elif key == keys.D:
            update_dancer(1)
            if move_list[current_move] == 1:
                score_p2 += 1
                next_move()
            else:
                game_over = True
        elif key == keys.S:
            update_dancer(2)
            if move_list[current_move] == 2:
                score_p2 += 1
                next_move()
            else:
                game_over = True
        elif key == keys.A:
            update_dancer(3)
            if move_list[current_move] == 3:
                score_p2 += 1
                next_move()
            else:
                game_over = True

    if moves_complete:
        current_move = 0
        moves_complete = False
        current_player = 2 if current_player == 1 else 1
        generate_moves()


def update():
    global game_over, current_move, moves_complete
    if not game_over:
        if moves_complete:
            generate_moves()
            moves_complete = False
            current_move = 0
    else:
        music.stop()


generate_moves()
music.play("audio")

pgzrun.go()